import requests #模拟浏览器发请求
#指定URL
#发起请求
#获取响应数据
#持久化存储


#爬取豆瓣首页数据
if __name__ == "__main__":
    #step1 指定URL
    url = 'https://www.baidu.com/'
    #step2 发起请求
    response=requests.get(url=url)
    #step3 获取响应数据
    page_text = response.text
    print(page_text)
    #持久化存储数据
    with open('./douban.html','w',encoding='utf-8') as fp:
        fp.write(page_text)
    print('爬取数据结束！！！')
