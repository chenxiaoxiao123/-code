# import MySQLdb
# print('连接到mysql服务器...')
# db = MySQLdb.connect('127.0.0.1', "root", "1234", "pachong")
# print('连接上了!')
import requests
from lxml import etree
import pymysql
import MySQLdb
def get_text(text):
    if text:
        return text[0]
    return ''
def create():
    # db = pymysql.connect("localhost", "root", "123", "lianxi",charset='utf8')  # 连接数据库
    db = MySQLdb.connect('127.0.0.1', "root", "1234", "pachong")
    cursor = db.cursor()
    cursor.execute("DROP TABLE IF EXISTS a1")

    sql = """CREATE TABLE a1 (
            ID INT PRIMARY KEY AUTO_INCREMENT,
            药物名字  char (255),
            药物价格  char (70),
            药物网址  CHAR(255),
            药店ID   char (60)      )DEFAULT CHARSET =utf8"""

    cursor.execute(sql)

    db.close()



    # db = pymysql.connect("localhost", "root", "123", "lianxi",charset='utf8')
    db = MySQLdb.connect('127.0.0.1', "root", "1234", "pachong")
    cursor = db.cursor()
    url_list = 'https://www.111.com.cn/categories/953710-a0-b0-c31-d0-e0-f0-g0-h0-i0-j%s.html'
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36"}

    for i in range(1, 30):
        response = requests.get(url_list % i, headers=headers)
        re=response.text
        content = etree.HTML(re)

        li_list = content.xpath('//ul[@id="itemSearchList"]/li')
        ##单价，描述，详情页链接
        for li in li_list:
            # print(li)
            price = get_text(li.xpath(
                './/div[@isrecom="0"]/p[1]/textarea/span/text()|.//div[@isrecom="0"]/p[1]/span/text()|.//div[@isrecom="0"]/p[1]/span/u/text()')).strip()
            name = li.xpath('.//div[@isrecom="0"]/p[2]/a/text()')[1].strip()

            url = get_text(li.xpath('.//div[@class="itemSearchResultCon"]/a[1]/@href')).strip()
            infos = []
            item = {}
            item['价格'] = price
            item['名字'] = name

            item['地址'] = 'https:' + url
            infos.append(item)
            print(item['价格'])
            print(item['地址'])
            print(item['名字'])
            a=1
            insert_sql = 'INSERT INTO a (药物价格,药物名字,药物网址,药店ID) VALUES (%s,%s,%s,%s)'
            cursor.execute(insert_sql, (item['价格'],item['名字'] ,item['地址'],a))


    try:

        db.commit()
        print('插入数据成功')
    except:
        db.rollback()
        print("插入数据失败")
    db.close()
if __name__ == '__main__':
    create()