import requests
import json

if __name__ == "__main__":
    url = 'https://movie.douban.com/j/chart/top_list?'
    param = {
        'type': '13',
        'interval_id': '100:90',
        'action': '',
        'start': '1',#从库中第几部电影去取
        'limit': '20'#一次取出的个数
    }
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36 Edg/88.0.705.74"
    }

    responce = requests.get(url=url,params=param,headers=headers)
    list_data = responce.json()
    fp = open('./douban.json','w',encoding='utf-8')
    json.dump(list_data,fp=fp,ensure_ascii=False)

    print('over!!!')