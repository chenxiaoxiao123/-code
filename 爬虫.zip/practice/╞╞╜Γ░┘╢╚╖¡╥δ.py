import requests
import json
if __name__ == "__main__":
    # 1、指定URL
    post_url = 'https://fanyi.baidu.com/sug'
    # 2、进行URL伪装
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36 Edg/88.0.705.74"
    }
    #3、post请求参数处理（同get处理一致）
    data = {
        'kw': 'dog'
    }
    response = requests.post(url=post_url,data=data,headers=headers)
    dic_obj = response.json()
    print(dic_obj)

    #持久化存储
    fp = open('./dog.json','w',encoding='utf-8')
    json.dump(dic_obj,fp=fp,ensure_ascii=False)
    print('over!!!')