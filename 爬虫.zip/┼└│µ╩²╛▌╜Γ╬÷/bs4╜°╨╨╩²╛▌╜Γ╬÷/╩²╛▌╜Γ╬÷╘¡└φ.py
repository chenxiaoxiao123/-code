#对象的实例化：
from bs4 import BeautifulSoup
if __name__ == "__main__":
    #将本地的HTML文档中的数据加载到该对象中
    fp = open('./校园.html','r',encoding='utf-8')
    soup = BeautifulSoup(fp,'lxml')
    # print(soup)
    # print(soup.div)#返回的是第一次出现的div
    # print(soup.find('div'))#返回的是第一次出现的div
    # print(soup.find('div',class_="item-text " ))#返回符合条件的div
