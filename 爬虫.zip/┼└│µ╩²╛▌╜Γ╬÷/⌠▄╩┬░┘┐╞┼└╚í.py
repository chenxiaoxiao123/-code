#图片爬取
import requests
if __name__ == "__main__":
    url = 'https://pic.qiushibaike.com/system/pictures/12409/124093901/medium/BOOQFJZ6QUGT24K2.jpg'
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36 Edg/88.0.705.74"
    }
    #content返回的是图片的二进制数
    img_data = requests.get(url=url,headers=headers).content

    #wb是写入二进制数据
    with open('./qiutu.jpg','wb') as fp:
        fp.write(img_data)
