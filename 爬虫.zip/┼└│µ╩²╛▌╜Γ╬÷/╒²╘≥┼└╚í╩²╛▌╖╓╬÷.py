#需求：分页爬取糗事百科中糗图板块的所有图片
import re
import requests
import os
import MySQLdb as mdb
import sys
if __name__ == "__main__":
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36 Edg/88.0.705.74"
    }

    #如果该目录下没有改文件夹，那么创建文件
    if not os.path.exists('./qiutuLibs1'):
        os.mkdir('./qiutuLibs1')

    # 分页爬取糗事百科中的图片，需要设计一个通用的URL模板
    url = 'https://www.qiushibaike.com/imgrank/page/%d/'
    for pageNum in range(1,10):
        new_url = format(url%pageNum)
        #使用通用爬虫对URL对应的一整张页面进行爬取
        page_text = requests.get(url=new_url,headers=headers).text
        #使用聚焦爬虫将页面所有的糗图进行解析爬取
        ex = '<div class="thumb">.*?<img src="(.*?)" alt.*?></div>'
        img_src_list = re.findall(ex,page_text,re.S)
        print(img_src_list)
        for src in img_src_list:
            #拼接出一个完整的图片
            src = 'http:'+src
            #请求到了一个完整的图片二进制数据
            img_data = requests.get(url=src,headers=headers).content
            #存储图片路径（在此之前，要生成一个文件夹）
            #生成图片名称
            img_name = src.split('/')[-1]
            #图片存储路径
            img_path = './qiutuLibs1/'+img_name
            with open(img_path,'wb') as fp:
                fp.write(img_data)
                print(img_name,'下载成功！！！！！')
            # !/usr/bin/python
            print(img_data)
            # -*- coding: utf-8 -*-

            conn = mdb.connect('127.0.0.1', "root", "1234", "pachong")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO Images SET Data='%s'" % mdb.escape_string(bin(img_data))
            conn.commit()
            cursor.close()
            conn.close()

