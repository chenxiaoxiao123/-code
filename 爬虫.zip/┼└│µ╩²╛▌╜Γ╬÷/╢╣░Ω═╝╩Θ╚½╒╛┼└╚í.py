import requests
from bs4 import BeautifulSoup
if __name__ == "__main__":
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36 Edg/88.0.705.74"
    }
    url = 'https://book.douban.com/tag/%E5%B0%8F%E8%AF%B4'
    page_text = requests.get(url=url,headers=headers).text
    soup = BeautifulSoup(page_text,'lxml')
    fp = open('./yaojianju.text', 'w', encoding='utf-8')
    fp.write(str(soup))
    print('over!!!')
    # print(soup)