import MySQLdb
# conn=MySQLdb.connect(host=’127.0.0.1',port=3306,user='root',passwd='1234',charset='utf8')
conn = MySQLdb.connect('127.0.0.1', "root", "1234", "pachong")
print('successfully connect')
cursor = conn.cursor()
fin = open("./0KEH5EZYXP40K8ZV.jpg",'rb')   #'rb'加上才能将图片读取为二进制
img = fin.read()                 #将二进制数据读取到img中
fin.close()

sql = "INSERT INTO employee VALUES  (%s,%s);"   #将数据插入到mysql数据库中，指令
args = ('1',img)                              #对应表格的数据

cursor.execute(sql,args)                      #执行相关操作
conn.commit()                                 #更新数据库
#print(2)
cursor.close()
conn.close()
